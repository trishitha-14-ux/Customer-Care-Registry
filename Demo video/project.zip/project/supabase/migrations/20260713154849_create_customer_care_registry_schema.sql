/*
# Customer Care Registry - Initial Schema

## Purpose
A centralized system to record and manage customer interactions, issues, and feedback.
Helps businesses streamline support processes, track inquiries, and analyze trends.

## New Tables

1. `customers`
   - `id` (uuid, primary key)
   - `name` (text, not null) - customer's full name
   - `email` (text, not null) - contact email
   - `phone` (text) - optional phone number
   - `company` (text) - optional company name
   - `status` (text, default 'active') - active / inactive
   - `created_at` (timestamptz, default now())

2. `issues`
   - `id` (uuid, primary key)
   - `customer_id` (uuid, FK -> customers.id ON DELETE CASCADE)
   - `title` (text, not null) - short summary of the issue
   - `description` (text) - detailed description
   - `status` (text, default 'open') - open / in_progress / resolved / closed
   - `priority` (text, default 'medium') - low / medium / high / urgent
   - `category` (text, default 'general') - billing / technical / general / product / service
   - `assigned_to` (text) - agent name handling the issue
   - `created_at` (timestamptz, default now())
   - `updated_at` (timestamptz, default now())
   - `resolved_at` (timestamptz, nullable)

3. `interactions`
   - `id` (uuid, primary key)
   - `issue_id` (uuid, FK -> issues.id ON DELETE CASCADE)
   - `customer_id` (uuid, FK -> customers.id ON DELETE CASCADE)
   - `type` (text, default 'note') - call / email / chat / note / meeting
   - `subject` (text) - short subject line
   - `content` (text, not null) - interaction details
   - `created_at` (timestamptz, default now())

4. `feedback`
   - `id` (uuid, primary key)
   - `customer_id` (uuid, FK -> customers.id ON DELETE CASCADE)
   - `issue_id` (uuid, FK -> issues.id ON DELETE SET NULL, nullable)
   - `rating` (integer, 1-5) - customer satisfaction score
   - `comment` (text) - optional feedback text
   - `created_at` (timestamptz, default now())

## Security
- RLS enabled on all tables.
- Single-tenant app with no sign-in: all CRUD operations allowed for anon + authenticated
  roles so the anon-key frontend client can read and write data.
- `USING (true)` is intentional here because the data is intentionally shared/public
  within this single-tenant application.

## Notes
1. Issues reference customers via foreign key; deleting a customer cascades to their issues.
2. Interactions reference both issues and customers; deleting either cascades.
3. Feedback optionally links to an issue; if the issue is deleted, the link is set to null
   but the feedback record remains.
4. Indexes added on foreign keys and frequently-filtered columns (status, priority, category).
*/

CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  company text,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_customers" ON customers;
CREATE POLICY "anon_select_customers" ON customers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_customers" ON customers;
CREATE POLICY "anon_insert_customers" ON customers FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_customers" ON customers;
CREATE POLICY "anon_update_customers" ON customers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_customers" ON customers;
CREATE POLICY "anon_delete_customers" ON customers FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'open',
  priority text NOT NULL DEFAULT 'medium',
  category text NOT NULL DEFAULT 'general',
  assigned_to text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

ALTER TABLE issues ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_issues" ON issues;
CREATE POLICY "anon_select_issues" ON issues FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_issues" ON issues;
CREATE POLICY "anon_insert_issues" ON issues FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_issues" ON issues;
CREATE POLICY "anon_update_issues" ON issues FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_issues" ON issues;
CREATE POLICY "anon_delete_issues" ON issues FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'note',
  subject text,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE interactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_interactions" ON interactions;
CREATE POLICY "anon_select_interactions" ON interactions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_interactions" ON interactions;
CREATE POLICY "anon_insert_interactions" ON interactions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_interactions" ON interactions;
CREATE POLICY "anon_update_interactions" ON interactions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_interactions" ON interactions;
CREATE POLICY "anon_delete_interactions" ON interactions FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  issue_id uuid REFERENCES issues(id) ON DELETE SET NULL,
  rating integer NOT NULL DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_feedback" ON feedback;
CREATE POLICY "anon_select_feedback" ON feedback FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_feedback" ON feedback;
CREATE POLICY "anon_insert_feedback" ON feedback FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_feedback" ON feedback;
CREATE POLICY "anon_update_feedback" ON feedback FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_feedback" ON feedback;
CREATE POLICY "anon_delete_feedback" ON feedback FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_issues_customer_id ON issues(customer_id);
CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
CREATE INDEX IF NOT EXISTS idx_issues_priority ON issues(priority);
CREATE INDEX IF NOT EXISTS idx_issues_category ON issues(category);
CREATE INDEX IF NOT EXISTS idx_interactions_issue_id ON interactions(issue_id);
CREATE INDEX IF NOT EXISTS idx_interactions_customer_id ON interactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_feedback_customer_id ON feedback(customer_id);
CREATE INDEX IF NOT EXISTS idx_feedback_issue_id ON feedback(issue_id);
CREATE INDEX IF NOT EXISTS idx_feedback_rating ON feedback(rating);
