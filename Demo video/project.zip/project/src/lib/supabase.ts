import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  company: string | null;
  status: string;
  created_at: string;
};

export type Issue = {
  id: string;
  customer_id: string;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  category: string;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
  customer?: Customer;
};

export type Interaction = {
  id: string;
  issue_id: string;
  customer_id: string;
  type: string;
  subject: string | null;
  content: string;
  created_at: string;
  issue?: Issue;
  customer?: Customer;
};

export type Feedback = {
  id: string;
  customer_id: string;
  issue_id: string | null;
  rating: number;
  comment: string | null;
  created_at: string;
  customer?: Customer;
  issue?: Issue;
};

export type IssueStatus = 'open' | 'in_progress' | 'resolved' | 'closed';
export type IssuePriority = 'low' | 'medium' | 'high' | 'urgent';
export type IssueCategory = 'billing' | 'technical' | 'general' | 'product' | 'service';

export const ISSUE_STATUSES: IssueStatus[] = ['open', 'in_progress', 'resolved', 'closed'];
export const ISSUE_PRIORITIES: IssuePriority[] = ['low', 'medium', 'high', 'urgent'];
export const ISSUE_CATEGORIES: IssueCategory[] = ['billing', 'technical', 'general', 'product', 'service'];
export const INTERACTION_TYPES = ['call', 'email', 'chat', 'note', 'meeting'];
