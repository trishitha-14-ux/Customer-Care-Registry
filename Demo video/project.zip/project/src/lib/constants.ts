export const STATUS_STYLES: Record<string, string> = {
  open: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
  in_progress: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
  resolved: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
  closed: 'bg-slate-100 text-slate-600 ring-1 ring-slate-200',
};

export const PRIORITY_STYLES: Record<string, string> = {
  low: 'bg-slate-50 text-slate-600 ring-1 ring-slate-200',
  medium: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
  high: 'bg-orange-50 text-orange-700 ring-1 ring-orange-200',
  urgent: 'bg-rose-50 text-rose-700 ring-1 ring-rose-200',
};

export const CATEGORY_STYLES: Record<string, string> = {
  billing: 'bg-violet-50 text-violet-700 ring-1 ring-violet-200',
  technical: 'bg-cyan-50 text-cyan-700 ring-1 ring-cyan-200',
  general: 'bg-slate-50 text-slate-600 ring-1 ring-slate-200',
  product: 'bg-teal-50 text-teal-700 ring-1 ring-teal-200',
  service: 'bg-indigo-50 text-indigo-700 ring-1 ring-indigo-200',
};

export const INTERACTION_STYLES: Record<string, string> = {
  call: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
  email: 'bg-cyan-50 text-cyan-700 ring-1 ring-cyan-200',
  chat: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
  note: 'bg-slate-50 text-slate-600 ring-1 ring-slate-200',
  meeting: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
};

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatDateTime(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
}
