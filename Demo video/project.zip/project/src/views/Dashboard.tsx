import { useEffect, useState, useCallback } from 'react';
import {
  Users,
  AlertCircle,
  MessageSquare,
  Star,
  TrendingUp,
  Clock,
  CheckCircle2,
  ArrowUpRight,
  Activity,
} from 'lucide-react';
import { supabase, type Issue, type Feedback } from '../lib/supabase';
import { LoadingSpinner, ErrorState } from '../components/States';
import { StatusBadge, PriorityBadge } from '../components/Badge';
import { formatDate, timeAgo } from '../lib/constants';

type Stats = {
  totalCustomers: number;
  totalIssues: number;
  openIssues: number;
  resolvedIssues: number;
  totalFeedback: number;
  avgRating: number;
};

type StatusCount = { status: string; count: number };
type CategoryCount = { category: string; count: number };
type PriorityCount = { priority: string; count: number };

export function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentIssues, setRecentIssues] = useState<Issue[]>([]);
  const [recentFeedback, setRecentFeedback] = useState<Feedback[]>([]);
  const [statusCounts, setStatusCounts] = useState<StatusCount[]>([]);
  const [categoryCounts, setCategoryCounts] = useState<CategoryCount[]>([]);
  const [priorityCounts, setPriorityCounts] = useState<PriorityCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const [customersRes, issuesRes, feedbackRes, recentIssuesRes, recentFeedbackRes] = await Promise.all([
        supabase.from('customers').select('id', { count: 'exact', head: true }),
        supabase.from('issues').select('id, status, priority, category', { count: 'exact', head: false }),
        supabase.from('feedback').select('rating'),
        supabase
          .from('issues')
          .select('*, customer:customers(*)')
          .order('created_at', { ascending: false })
          .limit(5),
        supabase
          .from('feedback')
          .select('*, customer:customers(*)')
          .order('created_at', { ascending: false })
          .limit(5),
      ]);

      if (customersRes.error) throw customersRes.error;
      if (issuesRes.error) throw issuesRes.error;
      if (feedbackRes.error) throw feedbackRes.error;
      if (recentIssuesRes.error) throw recentIssuesRes.error;
      if (recentFeedbackRes.error) throw recentFeedbackRes.error;

      const issues = issuesRes.data ?? [];
      const ratings = feedbackRes.data ?? [];

      const openCount = issues.filter((i) => i.status === 'open' || i.status === 'in_progress').length;
      const resolvedCount = issues.filter((i) => i.status === 'resolved').length;
      const avgRating = ratings.length > 0 ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length : 0;

      setStats({
        totalCustomers: customersRes.count ?? 0,
        totalIssues: issuesRes.count ?? 0,
        openIssues: openCount,
        resolvedIssues: resolvedCount,
        totalFeedback: ratings.length,
        avgRating: avgRating,
      });

      const sCounts: Record<string, number> = {};
      const cCounts: Record<string, number> = {};
      const pCounts: Record<string, number> = {};
      issues.forEach((i) => {
        sCounts[i.status] = (sCounts[i.status] ?? 0) + 1;
        cCounts[i.category] = (cCounts[i.category] ?? 0) + 1;
        pCounts[i.priority] = (pCounts[i.priority] ?? 0) + 1;
      });

      setStatusCounts(Object.entries(sCounts).map(([status, count]) => ({ status, count })));
      setCategoryCounts(Object.entries(cCounts).map(([category, count]) => ({ category, count })));
      setPriorityCounts(Object.entries(pCounts).map(([priority, count]) => ({ priority, count })));
      setRecentIssues(recentIssuesRes.data ?? []);
      setRecentFeedback(recentFeedbackRes.data ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (loading) return <LoadingSpinner label="Loading dashboard..." />;
  if (error) return <ErrorState message={error} />;
  if (!stats) return null;

  const maxCategoryCount = Math.max(...categoryCounts.map((c) => c.count), 1);
  const maxPriorityCount = Math.max(...priorityCounts.map((p) => p.count), 1);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="mt-1 text-sm text-slate-500">Overview of customer care metrics and trends</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Users}
          label="Total Customers"
          value={stats.totalCustomers}
          color="text-blue-600 bg-blue-50"
        />
        <StatCard
          icon={AlertCircle}
          label="Open Issues"
          value={stats.openIssues}
          sublabel={`${stats.totalIssues} total`}
          color="text-amber-600 bg-amber-50"
        />
        <StatCard
          icon={CheckCircle2}
          label="Resolved Issues"
          value={stats.resolvedIssues}
          color="text-emerald-600 bg-emerald-50"
        />
        <StatCard
          icon={Star}
          label="Avg. Rating"
          value={stats.avgRating.toFixed(1)}
          sublabel={`${stats.totalFeedback} reviews`}
          color="text-violet-600 bg-violet-50"
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Issue status breakdown */}
        <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-200">
          <div className="mb-4 flex items-center gap-2">
            <Activity className="h-5 w-5 text-slate-400" />
            <h3 className="text-sm font-semibold text-slate-900">Issues by Status</h3>
          </div>
          <div className="space-y-3">
            {statusCounts.length === 0 && (
              <p className="text-sm text-slate-400">No issues yet</p>
            )}
            {statusCounts.map(({ status, count }) => {
              const total = stats.totalIssues || 1;
              const pct = (count / total) * 100;
              return (
                <div key={status}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <StatusBadge status={status} />
                    <span className="font-medium text-slate-600">{count}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-slate-700 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Issues by category */}
        <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-200">
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-slate-400" />
            <h3 className="text-sm font-semibold text-slate-900">Issues by Category</h3>
          </div>
          <div className="space-y-3">
            {categoryCounts.length === 0 && (
              <p className="text-sm text-slate-400">No issues yet</p>
            )}
            {categoryCounts.map(({ category, count }) => (
              <div key={category}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium capitalize text-slate-700">{category}</span>
                  <span className="font-medium text-slate-500">{count}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 transition-all duration-500"
                    style={{ width: `${(count / maxCategoryCount) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Issues by priority */}
        <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-200">
          <div className="mb-4 flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-slate-400" />
            <h3 className="text-sm font-semibold text-slate-900">Issues by Priority</h3>
          </div>
          <div className="space-y-3">
            {priorityCounts.length === 0 && (
              <p className="text-sm text-slate-400">No issues yet</p>
            )}
            {priorityCounts.map(({ priority, count }) => (
              <div key={priority}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <PriorityBadge priority={priority} />
                  <span className="font-medium text-slate-600">{count}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-slate-600 to-slate-800 transition-all duration-500"
                    style={{ width: `${(count / maxPriorityCount) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Recent issues */}
        <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-200">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-slate-400" />
              <h3 className="text-sm font-semibold text-slate-900">Recent Issues</h3>
            </div>
          </div>
          <div className="space-y-3">
            {recentIssues.length === 0 && (
              <p className="text-sm text-slate-400">No issues recorded yet</p>
            )}
            {recentIssues.map((issue) => (
              <div
                key={issue.id}
                className="flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-slate-50"
              >
                <div className="flex-1 min-w-0">
                  <p className="truncate text-sm font-medium text-slate-900">{issue.title}</p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {issue.customer?.name ?? 'Unknown'} · {timeAgo(issue.created_at)}
                  </p>
                </div>
                <StatusBadge status={issue.status} />
              </div>
            ))}
          </div>
        </div>

        {/* Recent feedback */}
        <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-200">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-slate-400" />
              <h3 className="text-sm font-semibold text-slate-900">Recent Feedback</h3>
            </div>
          </div>
          <div className="space-y-3">
            {recentFeedback.length === 0 && (
              <p className="text-sm text-slate-400">No feedback yet</p>
            )}
            {recentFeedback.map((fb) => (
              <div
                key={fb.id}
                className="flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-slate-50"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-slate-900">{fb.customer?.name ?? 'Unknown'}</p>
                    <StarRating rating={fb.rating} />
                  </div>
                  {fb.comment && (
                    <p className="mt-0.5 truncate text-xs text-slate-500">{fb.comment}</p>
                  )}
                  <p className="mt-0.5 text-xs text-slate-400">{formatDate(fb.created_at)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sublabel,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  sublabel?: string;
  color: string;
}) {
  return (
    <div className="rounded-2xl bg-white p-5 ring-1 ring-slate-200 transition-shadow hover:shadow-md">
      <div className="flex items-center justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${color}`}>
          <Icon className="h-5 w-5" />
        </div>
        <ArrowUpRight className="h-4 w-4 text-slate-300" />
      </div>
      <p className="mt-4 text-2xl font-bold text-slate-900">{value}</p>
      <p className="mt-1 text-sm text-slate-500">{label}</p>
      {sublabel && <p className="mt-0.5 text-xs text-slate-400">{sublabel}</p>}
    </div>
  );
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-3 w-3 ${i < rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`}
        />
      ))}
    </div>
  );
}
