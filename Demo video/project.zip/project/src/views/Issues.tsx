import { useEffect, useState, useCallback } from 'react';
import {
  AlertCircle,
  Plus,
  Search,
  Pencil,
  Trash2,
  ChevronRight,
  MessageSquarePlus,
} from 'lucide-react';
import {
  supabase,
  type Issue,
  type Customer,
  type Interaction,
  ISSUE_STATUSES,
  ISSUE_PRIORITIES,
  ISSUE_CATEGORIES,
  INTERACTION_TYPES,
} from '../lib/supabase';
import { Modal, ConfirmDialog } from '../components/Modal';
import { LoadingSpinner, EmptyState, ErrorState } from '../components/States';
import { StatusBadge, PriorityBadge, CategoryBadge } from '../components/Badge';
import { formatDate, formatDateTime, timeAgo, INTERACTION_STYLES } from '../lib/constants';

type IssueForm = {
  customer_id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  category: string;
  assigned_to: string;
};

const emptyForm: IssueForm = {
  customer_id: '',
  title: '',
  description: '',
  status: 'open',
  priority: 'medium',
  category: 'general',
  assigned_to: '',
};

export function Issues() {
  const [issues, setIssues] = useState<Issue[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Issue | null>(null);
  const [form, setForm] = useState<IssueForm>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Issue | null>(null);
  const [detailIssue, setDetailIssue] = useState<Issue | null>(null);
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [interactionsLoading, setInteractionsLoading] = useState(false);
  const [interactionModalOpen, setInteractionModalOpen] = useState(false);
  const [interactionForm, setInteractionForm] = useState({
    type: 'note',
    subject: '',
    content: '',
  });
  const [savingInteraction, setSavingInteraction] = useState(false);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [issuesRes, customersRes] = await Promise.all([
        supabase
          .from('issues')
          .select('*, customer:customers(*)')
          .order('created_at', { ascending: false }),
        supabase.from('customers').select('*').order('name', { ascending: true }),
      ]);
      if (issuesRes.error) throw issuesRes.error;
      if (customersRes.error) throw customersRes.error;
      setIssues(issuesRes.data ?? []);
      setCustomers(customersRes.data ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load issues');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = issues.filter((i) => {
    const q = search.toLowerCase();
    const matchesSearch =
      i.title.toLowerCase().includes(q) ||
      (i.description ?? '').toLowerCase().includes(q) ||
      (i.customer?.name ?? '').toLowerCase().includes(q) ||
      (i.assigned_to ?? '').toLowerCase().includes(q);
    const matchesStatus = statusFilter === 'all' || i.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || i.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const openAdd = () => {
    setEditing(null);
    setForm({ ...emptyForm, customer_id: customers[0]?.id ?? '' });
    setModalOpen(true);
  };

  const openEdit = (i: Issue) => {
    setEditing(i);
    setForm({
      customer_id: i.customer_id,
      title: i.title,
      description: i.description ?? '',
      status: i.status,
      priority: i.priority,
      category: i.category,
      assigned_to: i.assigned_to ?? '',
    });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.title.trim() || !form.customer_id) return;
    setSaving(true);
    try {
      const resolvedAt =
        form.status === 'resolved' || form.status === 'closed'
          ? editing?.resolved_at ?? new Date().toISOString()
          : null;
      const payload = {
        customer_id: form.customer_id,
        title: form.title.trim(),
        description: form.description.trim() || null,
        status: form.status,
        priority: form.priority,
        category: form.category,
        assigned_to: form.assigned_to.trim() || null,
        updated_at: new Date().toISOString(),
        resolved_at: resolvedAt,
      };
      if (editing) {
        const { error } = await supabase.from('issues').update(payload).eq('id', editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('issues').insert(payload);
        if (error) throw error;
      }
      setModalOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save issue');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      const { error } = await supabase.from('issues').delete().eq('id', deleteTarget.id);
      if (error) throw error;
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete issue');
    }
  };

  const openDetail = async (issue: Issue) => {
    setDetailIssue(issue);
    setInteractionsLoading(true);
    try {
      const { data, error } = await supabase
        .from('interactions')
        .select('*, issue:issues(*), customer:customers(*)')
        .eq('issue_id', issue.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setInteractions(data ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load interactions');
    } finally {
      setInteractionsLoading(false);
    }
  };

  const saveInteraction = async () => {
    if (!detailIssue || !interactionForm.content.trim()) return;
    setSavingInteraction(true);
    try {
      const { error } = await supabase.from('interactions').insert({
        issue_id: detailIssue.id,
        customer_id: detailIssue.customer_id,
        type: interactionForm.type,
        subject: interactionForm.subject.trim() || null,
        content: interactionForm.content.trim(),
      });
      if (error) throw error;
      setInteractionModalOpen(false);
      setInteractionForm({ type: 'note', subject: '', content: '' });
      await openDetail(detailIssue);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save interaction');
    } finally {
      setSavingInteraction(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading issues..." />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Issues</h1>
          <p className="mt-1 text-sm text-slate-500">Track and manage customer inquiries</p>
        </div>
        <button
          onClick={openAdd}
          disabled={customers.length === 0}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-4 w-4" />
          New Issue
        </button>
      </div>

      {customers.length === 0 && (
        <div className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-700 ring-1 ring-amber-200">
          You need to add a customer before creating issues.
        </div>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search issues..."
            className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-sm text-slate-900 placeholder-slate-400 transition-colors focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-200"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 transition-colors focus:border-slate-400 focus:outline-none"
        >
          <option value="all">All Statuses</option>
          {ISSUE_STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace('_', ' ')}
            </option>
          ))}
        </select>
        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 transition-colors focus:border-slate-400 focus:outline-none"
        >
          <option value="all">All Priorities</option>
          {ISSUE_PRIORITIES.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={AlertCircle}
          title={search || statusFilter !== 'all' || priorityFilter !== 'all' ? 'No matching issues' : 'No issues yet'}
          message={
            search || statusFilter !== 'all' || priorityFilter !== 'all'
              ? 'Try adjusting your filters.'
              : 'Create your first issue to start tracking inquiries.'
          }
        />
      ) : (
        <div className="space-y-3">
          {filtered.map((issue) => (
            <div
              key={issue.id}
              className="group cursor-pointer rounded-2xl bg-white p-5 ring-1 ring-slate-200 transition-all hover:shadow-md"
              onClick={() => openDetail(issue)}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-sm font-semibold text-slate-900">{issue.title}</h3>
                    <PriorityBadge priority={issue.priority} />
                    <CategoryBadge category={issue.category} />
                  </div>
                  {issue.description && (
                    <p className="mt-1.5 line-clamp-2 text-sm text-slate-500">{issue.description}</p>
                  )}
                  <div className="mt-2 flex flex-wrap items-center gap-3 text-xs text-slate-400">
                    <span className="font-medium text-slate-600">{issue.customer?.name ?? 'Unknown'}</span>
                    <span>·</span>
                    <span>{timeAgo(issue.created_at)}</span>
                    {issue.assigned_to && (
                      <>
                        <span>·</span>
                        <span>Assigned to {issue.assigned_to}</span>
                      </>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={issue.status} />
                  <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openEdit(issue);
                      }}
                      className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                    >
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteTarget(issue);
                      }}
                      className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-300" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Issue detail modal */}
      <Modal
        open={!!detailIssue}
        onClose={() => setDetailIssue(null)}
        title="Issue Details"
        size="lg"
      >
        {detailIssue && (
          <div className="space-y-5">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-lg font-semibold text-slate-900">{detailIssue.title}</h3>
                <StatusBadge status={detailIssue.status} />
                <PriorityBadge priority={detailIssue.priority} />
                <CategoryBadge category={detailIssue.category} />
              </div>
              {detailIssue.description && (
                <p className="mt-2 text-sm text-slate-600">{detailIssue.description}</p>
              )}
              <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-400">
                <span>Customer: <span className="font-medium text-slate-600">{detailIssue.customer?.name}</span></span>
                {detailIssue.assigned_to && (
                  <span>Agent: <span className="font-medium text-slate-600">{detailIssue.assigned_to}</span></span>
                )}
                <span>Created: <span className="font-medium text-slate-600">{formatDate(detailIssue.created_at)}</span></span>
                {detailIssue.resolved_at && (
                  <span>Resolved: <span className="font-medium text-slate-600">{formatDate(detailIssue.resolved_at)}</span></span>
                )}
              </div>
            </div>

            <div>
              <div className="mb-3 flex items-center justify-between">
                <h4 className="text-sm font-semibold text-slate-900">Interaction History</h4>
                <button
                  onClick={() => setInteractionModalOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-200"
                >
                  <MessageSquarePlus className="h-3.5 w-3.5" />
                  Add Interaction
                </button>
              </div>
              {interactionsLoading ? (
                <LoadingSpinner label="Loading interactions..." />
              ) : interactions.length === 0 ? (
                <p className="py-6 text-center text-sm text-slate-400">No interactions recorded yet</p>
              ) : (
                <div className="space-y-3">
                  {interactions.map((int) => (
                    <div key={int.id} className="rounded-xl bg-slate-50 p-4 ring-1 ring-slate-100">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium capitalize ${INTERACTION_STYLES[int.type]}`}
                          >
                            {int.type}
                          </span>
                          {int.subject && (
                            <span className="text-sm font-medium text-slate-700">{int.subject}</span>
                          )}
                        </div>
                        <span className="text-xs text-slate-400">{formatDateTime(int.created_at)}</span>
                      </div>
                      <p className="mt-2 text-sm text-slate-600">{int.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* Add/Edit issue modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Issue' : 'New Issue'}
        size="lg"
      >
        <div className="space-y-4">
          <Field label="Customer" required>
            <select
              value={form.customer_id}
              onChange={(e) => setForm({ ...form, customer_id: e.target.value })}
              className="form-input"
            >
              <option value="">Select a customer...</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.company ? `(${c.company})` : ''}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Title" required>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="form-input"
              placeholder="Brief summary of the issue"
            />
          </Field>
          <Field label="Description">
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="form-input min-h-[80px] resize-y"
              placeholder="Detailed description of the issue..."
            />
          </Field>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
            <Field label="Status">
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
                className="form-input"
              >
                {ISSUE_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s.replace('_', ' ')}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Priority">
              <select
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}
                className="form-input"
              >
                {ISSUE_PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Category">
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="form-input"
              >
                {ISSUE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </Field>
          </div>
          <Field label="Assigned To">
            <input
              type="text"
              value={form.assigned_to}
              onChange={(e) => setForm({ ...form, assigned_to: e.target.value })}
              className="form-input"
              placeholder="Agent name"
            />
          </Field>
          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={() => setModalOpen(false)}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={save}
              disabled={saving || !form.title.trim() || !form.customer_id}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Update' : 'Create Issue'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Add interaction modal */}
      <Modal
        open={interactionModalOpen}
        onClose={() => setInteractionModalOpen(false)}
        title="Add Interaction"
      >
        <div className="space-y-4">
          <Field label="Type">
            <select
              value={interactionForm.type}
              onChange={(e) => setInteractionForm({ ...interactionForm, type: e.target.value })}
              className="form-input"
            >
              {INTERACTION_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Subject">
            <input
              type="text"
              value={interactionForm.subject}
              onChange={(e) => setInteractionForm({ ...interactionForm, subject: e.target.value })}
              className="form-input"
              placeholder="Optional subject line"
            />
          </Field>
          <Field label="Content" required>
            <textarea
              value={interactionForm.content}
              onChange={(e) => setInteractionForm({ ...interactionForm, content: e.target.value })}
              className="form-input min-h-[100px] resize-y"
              placeholder="Interaction details..."
            />
          </Field>
          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={() => setInteractionModalOpen(false)}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={saveInteraction}
              disabled={savingInteraction || !interactionForm.content.trim()}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-50"
            >
              {savingInteraction ? 'Saving...' : 'Add'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Delete Issue"
        message={`Are you sure you want to delete "${deleteTarget?.title}"? This will also delete all related interactions.`}
      />
    </div>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-slate-700">
        {label}
        {required && <span className="ml-0.5 text-rose-500">*</span>}
      </label>
      {children}
    </div>
  );
}
