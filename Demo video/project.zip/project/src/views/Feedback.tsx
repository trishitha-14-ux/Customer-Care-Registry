import { useEffect, useState, useCallback } from 'react';
import { Star, Plus, Search, Trash2, MessageSquare } from 'lucide-react';
import { supabase, type Feedback, type Customer, type Issue } from '../lib/supabase';
import { Modal, ConfirmDialog } from '../components/Modal';
import { LoadingSpinner, EmptyState, ErrorState } from '../components/States';
import { formatDate } from '../lib/constants';

type FeedbackForm = {
  customer_id: string;
  issue_id: string;
  rating: number;
  comment: string;
};

export function Feedback() {
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<FeedbackForm>({
    customer_id: '',
    issue_id: '',
    rating: 5,
    comment: '',
  });
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Feedback | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [fbRes, custRes, issuesRes] = await Promise.all([
        supabase
          .from('feedback')
          .select('*, customer:customers(*), issue:issues(*)')
          .order('created_at', { ascending: false }),
        supabase.from('customers').select('*').order('name', { ascending: true }),
        supabase.from('issues').select('*, customer:customers(*)').order('created_at', { ascending: false }),
      ]);
      if (fbRes.error) throw fbRes.error;
      if (custRes.error) throw custRes.error;
      if (issuesRes.error) throw issuesRes.error;
      setFeedback(fbRes.data ?? []);
      setCustomers(custRes.data ?? []);
      setIssues(issuesRes.data ?? []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load feedback');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = feedback.filter((f) => {
    const q = search.toLowerCase();
    return (
      (f.customer?.name ?? '').toLowerCase().includes(q) ||
      (f.comment ?? '').toLowerCase().includes(q)
    );
  });

  const avgRating = feedback.length > 0 ? feedback.reduce((s, f) => s + f.rating, 0) / feedback.length : 0;

  const openAdd = () => {
    setForm({ customer_id: customers[0]?.id ?? '', issue_id: '', rating: 5, comment: '' });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.customer_id) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('feedback').insert({
        customer_id: form.customer_id,
        issue_id: form.issue_id || null,
        rating: form.rating,
        comment: form.comment.trim() || null,
      });
      if (error) throw error;
      setModalOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save feedback');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      const { error } = await supabase.from('feedback').delete().eq('id', deleteTarget.id);
      if (error) throw error;
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete feedback');
    }
  };

  const issuesForCustomer = form.customer_id
    ? issues.filter((i) => i.customer_id === form.customer_id)
    : [];

  if (loading) return <LoadingSpinner label="Loading feedback..." />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Feedback</h1>
          <p className="mt-1 text-sm text-slate-500">Customer satisfaction and reviews</p>
        </div>
        <button
          onClick={openAdd}
          disabled={customers.length === 0}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Plus className="h-4 w-4" />
          Add Feedback
        </button>
      </div>

      {feedback.length > 0 && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <MiniStat label="Total Reviews" value={feedback.length} />
          <MiniStat label="Average Rating" value={avgRating.toFixed(1)} />
          <MiniStat label="5-Star Reviews" value={feedback.filter((f) => f.rating === 5).length} />
          <MiniStat label="Needs Attention" value={feedback.filter((f) => f.rating <= 2).length} />
        </div>
      )}

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by customer or comment..."
          className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-10 pr-4 text-sm text-slate-900 placeholder-slate-400 transition-colors focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-200"
        />
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={MessageSquare}
          title={search ? 'No matching feedback' : 'No feedback yet'}
          message={search ? 'Try adjusting your search.' : 'Add customer feedback to track satisfaction.'}
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((fb) => (
            <div
              key={fb.id}
              className="group rounded-2xl bg-white p-5 ring-1 ring-slate-200 transition-all hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 text-sm font-semibold text-white">
                    {fb.customer?.name?.charAt(0).toUpperCase() ?? '?'}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">{fb.customer?.name ?? 'Unknown'}</h3>
                    <p className="text-xs text-slate-400">{formatDate(fb.created_at)}</p>
                  </div>
                </div>
                <button
                  onClick={() => setDeleteTarget(fb)}
                  className="rounded-lg p-1.5 text-slate-400 opacity-0 transition-all hover:bg-rose-50 hover:text-rose-600 group-hover:opacity-100"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
              <div className="mt-3 flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${i < fb.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`}
                  />
                ))}
              </div>
              {fb.comment && (
                <p className="mt-3 text-sm text-slate-600">{fb.comment}</p>
              )}
              {fb.issue && (
                <p className="mt-3 text-xs text-slate-400">
                  Issue: <span className="font-medium text-slate-500">{fb.issue.title}</span>
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Add Feedback">
        <div className="space-y-4">
          <Field label="Customer" required>
            <select
              value={form.customer_id}
              onChange={(e) => setForm({ ...form, customer_id: e.target.value, issue_id: '' })}
              className="form-input"
            >
              <option value="">Select a customer...</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          {form.customer_id && issuesForCustomer.length > 0 && (
            <Field label="Related Issue">
              <select
                value={form.issue_id}
                onChange={(e) => setForm({ ...form, issue_id: e.target.value })}
                className="form-input"
              >
                <option value="">None</option>
                {issuesForCustomer.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.title}
                  </option>
                ))}
              </select>
            </Field>
          )}
          <Field label="Rating" required>
            <div className="flex items-center gap-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setForm({ ...form, rating: i + 1 })}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`h-7 w-7 ${i < form.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                  />
                </button>
              ))}
            </div>
          </Field>
          <Field label="Comment">
            <textarea
              value={form.comment}
              onChange={(e) => setForm({ ...form, comment: e.target.value })}
              className="form-input min-h-[100px] resize-y"
              placeholder="Customer's feedback..."
            />
          </Field>
          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={() => setModalOpen(false)}
              className="rounded-lg px-4 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={save}
              disabled={saving || !form.customer_id}
              className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-50"
            >
              {saving ? 'Saving...' : 'Add Feedback'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Delete Feedback"
        message="Are you sure you want to delete this feedback entry?"
      />
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
      <p className="text-xl font-bold text-slate-900">{value}</p>
      <p className="mt-0.5 text-xs text-slate-500">{label}</p>
    </div>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium text-slate-700">
        {label}
        {required && <span className="ml-0.5 text-rose-500">*</span>}
      </label>
      {children}
    </div>
  );
}
