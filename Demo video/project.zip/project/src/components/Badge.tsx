import { STATUS_STYLES, PRIORITY_STYLES, CATEGORY_STYLES } from '../lib/constants';

export function Badge({ label, style }: { label: string; style?: string }) {
  const className = style ?? 'bg-slate-100 text-slate-600 ring-1 ring-slate-200';
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${className}`}>
      {label}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  return <Badge label={status.replace('_', ' ')} style={STATUS_STYLES[status]} />;
}

export function PriorityBadge({ priority }: { priority: string }) {
  return <Badge label={priority} style={PRIORITY_STYLES[priority]} />;
}

export function CategoryBadge({ category }: { category: string }) {
  return <Badge label={category} style={CATEGORY_STYLES[category]} />;
}
